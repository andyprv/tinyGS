<template>
<svg
   xmlns:dc="http://purl.org/dc/elements/1.1/"
   xmlns:cc="http://creativecommons.org/ns#"
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   sodipodi:docname="dibujo.svg"
   inkscape:version="1.0 (4035a4fb49, 2020-05-01)"
   id="svg865"
   version="1.1"
   viewBox="0 0 26.614882 32.60743"
   height="32.60743mm"
   width="26.614882mm">
  <defs
     id="defs859" />
  <sodipodi:namedview
     inkscape:window-maximized="1"
     inkscape:window-y="27"
     inkscape:window-x="0"
     inkscape:window-height="1376"
     inkscape:window-width="2560"
     fit-margin-bottom="0"
     fit-margin-right="0"
     fit-margin-left="0"
     fit-margin-top="0"
     showgrid="false"
     inkscape:document-rotation="0"
     inkscape:current-layer="layer1"
     inkscape:document-units="mm"
     inkscape:cy="70.627453"
     inkscape:cx="102.73841"
     inkscape:zoom="1.979899"
     inkscape:pageshadow="2"
     inkscape:pageopacity="0.0"
     borderopacity="1.0"
     bordercolor="#666666"
     pagecolor="#ffffff"
     id="base" />
  <metadata
     id="metadata862">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
        <dc:title></dc:title>
      </cc:Work>
    </rdf:RDF>
  </metadata>
  <g
     transform="translate(-17.043881,-25.662578)"
     id="layer1"
     inkscape:groupmode="layer"
     inkscape:label="Capa 1">
    <path
       inkscape:connector-curvature="0"
       id="path4687"
       d="m 25.921991,48.253567 a 6.8912181,6.9925593 0 0 0 -6.89157,6.99285 6.8912181,6.9925593 0 0 0 0.115239,1.25626 13.370907,12.473213 0 0 0 6.830073,1.76733 13.370907,12.473213 0 0 0 6.709669,-1.7017 6.8912181,6.9925593 0 0 0 0.127641,-1.32189 6.8912181,6.9925593 0 0 0 -6.891052,-6.99285 z"
       style="fill:#ffffff;fill-opacity:1;stroke:none;stroke-width:1.8693;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1;paint-order:markers stroke fill" />
    <path
       sodipodi:nodetypes="ccccc"
       inkscape:connector-curvature="0"
       id="path4689"
       d="m 20.976609,32.630947 c -2.291557,1.62608 -3.928037,4.66951 -3.932728,7.6469 1.65e-4,6.36686 4.830907,11.90608 11.197767,11.90596 2.85535,-0.005 6.161028,-1.29334 8.053771,-3.36436 z"
       style="fill:#ffffff;fill-opacity:1;stroke:none;stroke-width:1.52983;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1;paint-order:markers stroke fill" />
    <ellipse
       transform="matrix(0.75626911,0.65426067,-0.52791361,0.84929807,0,0)"
       ry="6.3669958"
       rx="11.07095"
       cy="12.510401"
       cx="46.270409"
       id="ellipse4691"
       style="fill:#ececec;fill-opacity:1;stroke:none;stroke-width:1.24244;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1;paint-order:markers stroke fill" />
    <path
       inkscape:connector-curvature="0"
       id="path4693"
       d="m 32.811492,55.214387 a 11.859003,10.110863 0 0 1 -6.929808,1.92184 11.859003,10.110863 0 0 1 -6.850229,-1.86603 6.8912181,6.9925593 0 0 0 0.114205,1.23248 13.370906,12.473213 0 0 0 6.830073,1.76733 13.370906,12.473213 0 0 0 6.709669,-1.7017 6.8912181,6.9925593 0 0 0 0.12764,-1.32188 6.8912181,6.9925593 0 0 0 -0.0016,-0.032 z"
       style="fill:#ececec;fill-opacity:1;stroke:none;stroke-width:1.8693;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1;paint-order:markers stroke fill" />
    <path
       inkscape:connector-curvature="0"
       id="path4695"
       d="m 36.595283,25.667464 c -1.353145,-0.05321 -2.330078,0.345703 -2.330078,0.345703 a 0.73340072,0.73340072 0 1 0 0.560547,1.355468 c 0,0 0.659493,-0.277749 1.712891,-0.236328 1.053398,0.04142 2.43204,0.394931 3.84375,1.80664 1.41171,1.41171 1.765219,2.79035 1.80664,3.84375 0.04142,1.0534 -0.236328,1.71289 -0.236328,1.71289 a 0.73340175,0.73340175 0 1 0 1.355469,0.56055 c 0,0 0.398911,-0.97693 0.345703,-2.33008 -0.05321,-1.35314 -0.565628,-3.15156 -2.236328,-4.822265 -1.6707,-1.6707 -3.469121,-2.183121 -4.822266,-2.236328 z m -0.818359,3.472653 c -0.840361,-0.0732 -1.472656,0.15625 -1.472656,0.15625 a 0.73257327,0.73257327 0 1 0 0.511719,1.3711 c 0,0 0.288877,-0.11391 0.833984,-0.0664 0.545107,0.0475 1.28133,0.25789 2.091797,1.06836 0.810466,0.81046 1.020861,1.54669 1.068359,2.09179 0.0475,0.54511 -0.06836,0.83399 -0.06836,0.83399 a 0.73265193,0.73265193 0 1 0 1.373047,0.51172 c 0,0 0.227521,-0.6323 0.154296,-1.47266 -0.07322,-0.84036 -0.446445,-1.95426 -1.492187,-3 -1.045743,-1.04574 -2.159639,-1.42092 -3,-1.49414 z"
       style="color:#000000;font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:medium;line-height:normal;font-family:sans-serif;font-variant-ligatures:normal;font-variant-position:normal;font-variant-caps:normal;font-variant-numeric:normal;font-variant-alternates:normal;font-feature-settings:normal;text-indent:0;text-align:start;text-decoration:none;text-decoration-line:none;text-decoration-style:solid;text-decoration-color:#000000;letter-spacing:normal;word-spacing:normal;text-transform:none;writing-mode:lr-tb;direction:ltr;text-orientation:mixed;dominant-baseline:auto;baseline-shift:baseline;text-anchor:start;white-space:normal;shape-padding:0;clip-rule:nonzero;display:inline;overflow:visible;visibility:visible;isolation:auto;mix-blend-mode:normal;color-interpolation:sRGB;color-interpolation-filters:linearRGB;solid-color:#000000;solid-opacity:1;vector-effect:none;fill:#ffffff;fill-opacity:1;fill-rule:nonzero;stroke:none;stroke-width:1.465;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-dashoffset:0;stroke-opacity:1;color-rendering:auto;image-rendering:auto;shape-rendering:auto;text-rendering:auto;enable-background:accumulate" />
    <path
       inkscape:connector-curvature="0"
       style="color:#000000;font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:medium;line-height:normal;font-family:sans-serif;font-variant-ligatures:normal;font-variant-position:normal;font-variant-caps:normal;font-variant-numeric:normal;font-variant-alternates:normal;font-feature-settings:normal;text-indent:0;text-align:start;text-decoration:none;text-decoration-line:none;text-decoration-style:solid;text-decoration-color:#000000;letter-spacing:normal;word-spacing:normal;text-transform:none;writing-mode:lr-tb;direction:ltr;text-orientation:mixed;dominant-baseline:auto;baseline-shift:baseline;text-anchor:start;white-space:normal;shape-padding:0;clip-rule:nonzero;display:inline;overflow:visible;visibility:visible;isolation:auto;mix-blend-mode:normal;color-interpolation:sRGB;color-interpolation-filters:linearRGB;solid-color:#000000;solid-opacity:1;vector-effect:none;fill:#ffffff;fill-opacity:1;fill-rule:nonzero;stroke:none;stroke-width:2.165;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-dashoffset:0;stroke-opacity:1;color-rendering:auto;image-rendering:auto;shape-rendering:auto;text-rendering:auto;enable-background:accumulate"
       d="m 35.158187,31.868407 a 2.3151042,2.3151042 0 0 0 -2.315104,2.31511 2.3151042,2.3151042 0 0 0 0.123507,0.73794 l -6.939628,6.8616 a 1.0834656,1.0834656 0 1 0 1.523421,1.54099 l 6.989238,-6.91173 a 2.3151042,2.3151042 0 0 0 0.618566,0.0863 2.3151042,2.3151042 0 0 0 2.315105,-2.3151 2.3151042,2.3151042 0 0 0 -2.315105,-2.31511 z m -2.18953,3.05873 a 2.3151042,2.3151042 0 0 0 1.567346,1.48415 2.3151042,2.3151042 0 0 1 -1.567346,-1.48415 z"
       id="path4697" />
  </g>
</svg>
</template>
